<?php 
session_start();
	require 'topheader.php';
?>
		<aside id="colorlib-hero">
			<div class="flexslider">
				<ul class="slides">
			   	<li style="background-image: url(images/banner/lake-tana.jpg);">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text">
				   				<div class="slider-text-inner text-center">
				   					<h1>Lake Tana</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			  	</ul>
		  	</div>
		</aside>

		<div id="colorlib-blog">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="wrap-division">
							<article class="animate-box">
								<div class="blog-img" style="background-image: url(images/destination/lake-tana-2.jpg);"></div>
								
                            </article>
                            <div class="desc">
                                <h2><a href="#">Lake Tana</a></h2>
                                <p>Lake Tana is the largest lake in Ethiopia and the source of the Blue Nile. The Lake has been formed by volcanic activity and it is Situated on the basaltic Plateau of the north-western highlands of Ethiopia covering an area of ca 3,050 km2  . It holds 50% of the Ethiopia’s fresh water. It is also contributes up to 60% of the Nile’s water.</p>
                            </div>
							
                        </div>
                    </div>
                    <div class="col-md-3">
						<div class="sidebar-wrap">
							<div class="side animate-box">
								<h3 class="sidebar-heading">Other Destinations</h3>
								<div class="blog-entry-side">
									<a href="bahir-dar.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/bahir-dar.jpg);"></span>
										<div class="desc">
											<h3>Bahir Dar</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="blue-nile.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/blue-nile.jpg);"></span>
										<div class="desc">
											<h3>Blue Nile Falls</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="gondar.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/gondar.jpg);"></span>
										<div class="desc">
											<h3>Gondar</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
                    
					
				</div>
			</div>
		</div>
	
		<div id="colorlib-subscribe" style="background-image: url(images/destination/lake-tana-3.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Life Goal: Travel & Travel</h2>
						<p>Experience the significant historical and cultural Lake Tana.</p>
					</div>
				</div>
			</div>
		</div>

		<div class="colorlib-tour" style="">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="f-tour" >
							<div class="row row-pb-md" >
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/lake-tana-4.jpg);">
												
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/lake-tana-5.jpg);">
											
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/lake-tana-6.jpg);">
		
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/lake-tana-7.jpg);">
												
											</a>
										</div>
									</div>
								</div>
								<div class="col-md-6 animate-box">
									<div class="desc">
										<div class="row">
											<div class="col-md-12">
												<h3>Lake Tana Islands and Churches</h3>
												<p>Lake Tana thirty-seven islands scattered about on the 3,000-square-kilometer surface of Ethiopia’s largest body of water.  Some twenty of these islands shelter churches and monasteries of significant historical and cultural interest.</p><br>
											</div>
											<div class="col-md-12">
												<h4>Places to Visit in Lake Tana</h4>
												<div class="row">
													<div class="col-md-6">
														<ul>
															<li><a>Dega Estefanos</a></li>
															<li><a>Ura Kidane Meret</a></li>
															<li><a>Outlet of the Blue Nile</a></li>
															<li><a>Narga Selassie</a></li>
														</ul>
													</div>
                                                    <div class="col-md-6">
														<ul>
															<li><a>Bete Selassie</a></li>
															<li><a>Tana Cherkos</a></li>
															<li><a>Zeghie Satekela Museum</a></li>
															<li><a>Bete Giorgis</a></li>
														</ul>
													</div>
													
												</div>
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
			</div>
		</div>

<?php require 'footer.php';?>
