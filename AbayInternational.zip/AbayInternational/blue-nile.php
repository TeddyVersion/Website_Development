<?php 
session_start();
	require 'topheader.php';
?>
		<aside id="colorlib-hero">
			<div class="flexslider">
				<ul class="slides">
			   	<li style="background-image: url(images/banner/blue-nile.jpg);">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text">
				   				<div class="slider-text-inner text-center">
				   					<h1>Blue Nile Falls</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			  	</ul>
		  	</div>
		</aside>

		<div id="colorlib-blog">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="wrap-division">
							<article class="animate-box">
								<div class="blog-img" style="background-image: url(images/destination/blue-nile-2.jpg);"></div>
								
                            </article>
                            <div class="desc">
                                <h2><a href="#">Blue Nile Falls</a></h2>
                                <p>The Blue Nile Falls is a waterfall on the Blue Nile river in Ethiopia. The Blue Nile Falls is one of the top must-see tourist attractions in Ethiopia. It is also known as Tis Abay, meaning ‘great smoke’. The Blue Nile falls get their water from the Blue Nile River whose source is the Lake Tana that is also located near the Bahir Dar city. The Blue Nile is one of the 2 tributaries which make up the River Nile, Africa’s longest river. An international river, the Nile traverses through 11 countries and is the main source of water for both Egypt and Sudan.</p>
                            </div>
							
                        </div>
                        
                
                    </div>
                    <div class="col-md-3">
						<div class="sidebar-wrap">
							<div class="side animate-box">
								<h3 class="sidebar-heading">Other Destinations</h3>
								<div class="blog-entry-side">
									<a href="bahir-dar.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/bahir-dar.jpg);"></span>
										<div class="desc">
											<h3>Bahir Dar</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="lake-tana.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/lake-tana.jpg);"></span>
										<div class="desc">
											<h3>Lake Tana</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="gondar.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/gondar.jpg);"></span>
										<div class="desc">
											<h3>Gondar</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
                    
					
				</div>
			</div>
		</div>
	
		<div id="colorlib-subscribe" style="background-image: url(images/destination/blue-nile-3.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Say Yes to New Adventure</h2>
						<p>Visit one of Ethiopia’s best known tourist attractions.</p>
					</div>
				</div>
			</div>
		</div>

		<div class="colorlib-tour" style="">
			<div class="container">
				<div class="row ">
					<div class="col-md-12">
						<div class="f-tour" >
							<div class="row row-pb-md justify-content-center" >
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/blue-nile-4.jpg);">
												
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/blue-nile-7.jpg);">
											
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/blue-nile-6.jpg);">
		
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/blue-nile-5.jpg);">
												
											</a>
										</div>
									</div>
								</div>
								<div class="col-md-6 animate-box">
									<div class="desc">
										<div class="row">
											<div class="col-md-12">
												<h3>Blue Nile</h3>
												<p>During the summer, fertile land is eroded from the Ethiopian highlands and carried along by the Blue Nile. The resulting dark, almost black, appearance gives rise to the name, The Blue Nile.</p><br>
                                                <p>The Blue Nilefalls are estimated to be between 37 and 45 meters high, consisting of four streams that originally varied from a trickle in the dry season to over 400 meters wide in the rainy season. It is considered one of Ethiopia’s best known tourist attractions. </p><br>
                                                <p>Various trips can be arranged in order to reach the Blue Nile Falls as it is a main tourist spot in Ethiopia.   The flora around the falls can also be appreciated; there are many plant species endemic only to that area. The Blue Nile Falls are also enriched with different types of wildlife that can only be found in Ethiopia.</p>
                                            </div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
			</div>
		</div>

<?php require 'footer.php';?>
