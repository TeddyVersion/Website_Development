<footer id="colorlib-footer" role="contentinfo">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-4 colorlib-widget">
						<h4>Abay International Tour and Travel</h4>
						<p>Our Company is a full-service travel agency dedicated in providing totally reliable and practical tour and travel solutions as it offers most competitive rates in the market. </p>
						<p>
							<ul class="colorlib-social-icons">
								<li><a href="#"><i class="icon-facebook"></i></a></li>
								<li><a href="#"><i class="icon-twitter"></i></a></li>
								<li><a href="#"><i class="icon-linkedin"></i></a></li>
							</ul>
						</p>
					</div>
					<div class="col-md-1"></div>
					<div class="col-md-3 colorlib-widget">
						<h4>Links</h4>
						<p>
							<ul class="colorlib-footer-links">
								<li><a href="home.php">Home</a></li>
								<li><a href="contact.php">Contact</a></li>
								<li><a href="about.php">About</a></li>
							</ul>
						</p>
					</div>
				

					<div class="col-md-4 col-md-push-1">
						<h4>Contact Information</h4>
						<ul class="colorlib-footer-links">
							<li>Kebele Fasilo, Bahirdar, <br> Ethiopia</li>
							<li><a href="tel://+251918760477">+251 918 76 04 77</a></li>
							<li><a href="mailto:info@abayintourandtravel.com">info@abayintourandtravel.com</a></li>
							<li><a href="mailto:abaybus1@gmail.com">abaybus1@gmail.com</a></li>
						</ul>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 text-center">
						<p>
						
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made by <a href="https://infobitsict.com" target="_blank">infobits</a>
</span> 
						</p>
					</div>
				</div>
			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up2"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- Owl carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>
