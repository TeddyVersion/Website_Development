<?php 
session_start();
	require 'topheader.php';
?>
		<aside id="colorlib-hero">
			<div class="flexslider">
				<ul class="slides">
			   	<li style="background-image: url(images/banner/gondar.jpg);">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text">
				   				<div class="slider-text-inner text-center">
				   					<h1>Gondar</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			  	</ul>
		  	</div>
		</aside>

		<div id="colorlib-blog">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="wrap-division">
							<article class="animate-box">
								<div class="blog-img" style="background-image: url(images/destination/gondar-2.jpg);"></div>
								
                            </article>
                            <div class="desc">
                                <h2><a href="#">Gondar</a></h2>
                                <p>Gondar, or Gonder, is a city in northern Ethiopia. It's known for the walled Fasil Ghebbi fortress and palace compound, once the seat of Ethiopian emperors. Fasil Ghebbi  is on the UNESCO World Heritage List and is part of the famous Ethiopia Historical Circuit. Dominating it is the immense 17th-century castle of Emperor Fasilides.</p>
                            </div>
							
                        </div>
                        
                
                    </div>
                    <div class="col-md-3">
						<div class="sidebar-wrap">
							<div class="side animate-box">
								<h3 class="sidebar-heading">Other Destinations</h3>
								<div class="blog-entry-side">
									<a href="bahir-dar.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/bahir-dar.jpg);"></span>
										<div class="desc">
											<h3>Bahir Dar</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="lake-tana.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/lake-tana.jpg);"></span>
										<div class="desc">
											<h3>Lake Tana</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="blue-nile.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/blue-nile.jpg);"></span>
										<div class="desc">
											<h3>Blue Nile</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
                    
					
				</div>
			</div>
		</div>
	
		<div id="colorlib-subscribe" style="background-image: url(images/destination/gondar-3.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Where Stories were Born</h2>
						<p>One of the most Interesting Historical Places in Ethiopia</p>
					</div>
				</div>
			</div>
		</div>

		<div class="colorlib-tour" style="">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="f-tour" >
							<div class="row row-pb-md" >
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/gondar-4.jpg);">
												
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/gondar-5.jpg);">
											
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/gondar-6.jpg);">
		
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/gondar-7.jpg);">
												
											</a>
										</div>
									</div>
								</div>
								<div class="col-md-6 animate-box">
									<div class="desc">
										<div class="row">
											<div class="col-md-12">
												<h3>Gondar City </h3>
												<p>It was the home of many emperors and princesses who led the country from the 12th century to the last decade of the 20th century, including Emperor Suseneos, Emperor Fasiledes, Empress Mentwab, Iyasu I, Tewodros II and Empress Taitu. </p><br>
											</div>
											<div class="col-md-12">
												<h4>Fasil Ghebbi</h4>
                                                <p>is not a single castle, but instead is the name given to the entire complex of castles and palaces in the area.</p><br>
												<div class="row">
													<div class="col-md-6">
														<ul>
															<li><a>Fasilides Castle</a></li>
															<li><a>Iyasu Palace</a></li>
															<li><a>Mentewab's Palace</a></li>
															<li><a>Fasilides Bath</a></li>
														</ul>
													</div>
													<div class="col-md-6">
														<ul>
															<li><a>Debre Birhan Selassie Church</a></li>
															<li><a>Gorgora</a></li>
															<li><a>Church of Debre Sina</a></li>
															<li><a>Monasteries</a></li>
														</ul>
													</div>
							
												</div>
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
			</div>
		</div>

<?php require 'footer.php';?>
