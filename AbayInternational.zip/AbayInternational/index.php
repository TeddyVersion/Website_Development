<?php 
session_start();
	require 'topheader.php';
?>

		<aside id="colorlib-hero" style="height:100vh;margin-bottom:90px;">
			<div class="flexslider">
				<ul class="slides" >
			   	<li style="background-image: url(images/banner/slider-1.jpg); height:100vh">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text" style="height:100vh">
				   				<div class="slider-text-inner text-center">
				   					<h2>5/7 Days Tour</h2>
				   					<h1>Amazing Memorable Tour</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			   	<li style="background-image: url(images/banner/slider-2.jpg); height:100vh">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text" style="height:100vh" >
				   				<div class="slider-text-inner text-center">
				   					<h2>Life Purpose</h2>
				   					<h1>Work Save Travel Repeat</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			   	<li style="background-image: url(images/banner/slider-3.jpg); height:100vh">
			   		<div class="overlay"></div>
			   		<div class="container-fluids">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text" style="height:100vh">
				   				<div class="slider-text-inner text-center">
				   					<h2>Abay International Tour & Travel</h2>
				   					<h1>Explore our tavel agency</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			   	<li style="background-image: url(images/banner/slider-4.jpg); height:100vh">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text" style="height:100vh">
				   				<div class="slider-text-inner text-center">
				   					<h2>Experience the</h2>
				   					<h1>Best Trip Ever</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>	   	
			  	</ul>
		  	</div>
		</aside>
	

		<div id="colorlib-services" >
			<div class="container" >
				<div class="row" >
					<div class="col-md-8 col-md-offset-2 text-center ">
						<h2>Abay International Tour and Travel</h2>
						<p>Our Company is a full-service travel agency dedicated in providing totally reliable and practical tour and travel solutions as it offers most competitive rates in the market. We expertly handle local and international travel services; including airline reservations, special and customized tours from simple to unique destinations for business or pleasure trips, hotel accommodations as well as car rentals.</p>
					</div>
				</div>
				<div class="row no-gutters" >
					<div class="col-md-4 animate-box text-center">
						<div class="services">
							<span class="icon">
								<i class="flaticon-around"></i>
							</span>
							<h3>Amazing Travel</h3>
							<p>Travelling to Ethiopia also means to return to the origin of humankind. With much care we have designed a choice of fantastic tours through Ethiopia for you. These round trips can be individually adjusted as per your personal wishes.</p>
						</div>
					</div>
					<div class="col-md-4 animate-box text-center">
						<div class="services">
							<span class="icon">
								<i class="flaticon-boat"></i>
							</span>
							<h3>Premium Tour Operator </h3>
							<p>We offer group tours as well as a wide range of tailor-made Ethiopia cultural and historic tours, photo safaris, animal- and bird watching trips, desert- and mountain trekking, eco-tourism and family-friendly tours. You may be assured that your holiday with us will be an experience of a lifetime.</p>
						</div>
					</div>
					<div class="col-md-4 animate-box text-center">
						<div class="services">
							<span class="icon">
								<i class="flaticon-car"></i>
							</span>
							<h3>Experiencing History </h3>
							<p>Observing the splendid diversity of the natural and animal world from a front-row seat, while gaining an insight into the lives of local people. Our goal is not just to meet your expectations but to exceed them every day that you are with us.</p>
						</div>
					</div>
				
				</div>
			</div>
		</div>
		
		<div id="colorlib-hotel" class="colorlib-light-grey">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Tour Packages</h2>
						<p>With a rich history and culture, Ethiopia easily stands out as one of the finest travel hotspots in Africa. It can surprise travelers with its natural beauty and cultural diversity. </p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="wrap-division">
								<div class="col-md-6 ">
									<div class="tour">
										<a href="5-Days-Northern-Ethiopia.php" class="tour-img" style="background-image: url(images/package/5-days.jpg);">
											<p class="price"><span>7,000 ETB</span> <small>/ person</small></p>
										</a>
										<span class="desc">
											<h2><a href="5-Days-Northern-Ethiopia.php">5 Days Northern Ethiopia</a></h2>
											<span class="city">Ethiopia</span>
										</span>
									</div>
								</div>

								<div class="col-md-6">
									<div class="tour">
										<a href="7-Days-Northern-Ethiopia.php" class="tour-img" style="background-image: url(images/package/7-days.jpg);">
											<p class="price"><span>8,500 ETB</span> <small>/ person</small></p>
										</a>
										<span class="desc">
											<h2><a href="7-Days-Northern-Ethiopia.php">7 Days Northern Ethiopia</a></h2>
											<span class="city">Ethiopia</span>
										</span>
									</div>
								</div>
							</div>
						</div>
						
					</div>

					
				</div>
			</div>
		</div>

		<div class="colorlib-tour ">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Popular Destination</h2>
						<p>The country of Ethiopia is the holiday destination of dreams. It is a nation that is defined by cultural diversity and beautiful scenery.</p>
					</div>
				</div>
			</div>
			<div class="tour-wrap">
				<a href="#" class="tour-entry animate-box">
					<div class="tour-img" style="background-image: url(images/destination/bahir-dar-1.jpg);">
					</div>
					<span class="desc">
						<h2>Bahir Dar</h2>
						<span class="city">Capital city of the Amhara region</span>
						<span class="price">Ethiopia</span>
					</span>
				</a>
				<a href="#" class="tour-entry animate-box">
					<div class="tour-img" style="background-image: url(images/destination/blue-nile-1.jpg);">
					</div>
					<span class="desc">
						<h2>Blue Nile Falls</h2>
						<span class="city">A waterfall on the Blue Nile river</span>
						<span class="price">Ethiopia</span>
					</span>
				</a>
				<a href="#" class="tour-entry animate-box">
					<div class="tour-img" style="background-image: url(images/destination/gondar-1.jpg);">
					</div>
					<span class="desc">
						<h2>Gondar</h2>
						<span class="city">known for the walled Fasil Ghebbi fortress</span>
						<span class="price">Ethiopia</span>
					</span>
				</a>
				<a href="#" class="tour-entry animate-box">
					<div class="tour-img" style="background-image: url(images/destination/lake-tana-1.jpg);">
					</div>
					<span class="desc">
						<h2>Lake Tana</h2>
						<span class="city">The largest lake in Ethiopia</span>
						<span class="price">Ethiopia</span>
					</span>
				</a>
				
			</div>
		</div>

		<div class="colorlib-tour" style="padding-top:0px !important">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>About Ethiopia</h2>
						<p>Ethiopia, located in the Horn of Africa, is a country split by the Great Rift Valley. With archaeological finds dating back more than 3 million years, it’s a place of ancient culture and history.</p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="f-tour">
							<div class="row row-pb-md">
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-12 animate-box">
											<a  href="tours.php" class="f-tour-img" style="background-image: url(images/about/ethiopia-1.jpg);">
												<div class="desc">
													<h3>Ethiopia</h3>
													<p style="color:#fff;">Cradle of Mankind</p>
												</div>
											</a>
										</div>
										
									</div>
								</div>
								<div class="col-md-6 animate-box">
									<div class="desc">
										<div class="row">
											<div class="col-md-12" style="padding-top:15px;">
												<h3>Ethiopia, Africa</h3>
												<p>Ethiopia is a country where human being started and it is considered the "cradle of mankind", Ethiopian is also the origin of coffee, and has 13 months with its own calendar system. Ethiopia has a total area of 1,100,000 square kilometers (420,000 sq mi) and over 110 million inhabitants and is the 13th-most populous country in the world and the 2nd-most populous in Africa.</p><br>
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="colorlib-intro" class="intro-img" style="background-image: url(images/banner/para-1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 animate-box">
						<div class="intro-desc">
							<div class="text-salebox">
								
								<div class="text-rights">
									<h3 class="title">Beauty, Charm, And Adventure.</h3>
									<p>Choose the travel plan you like the most to make your stay in Ethiopia unforgettable.</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 animate-box">
						<div class="video-wrap">
							<div class="video colorlib-video" style="background-image: url(images/about/blue-nile-1.jpg);">
								<a href="https://www.youtube.com/watch?v=ElG9sAiln4A&ab_channel=DjiboutiUnited" class="popup-vimeo"><i class="icon-video"></i></a>
								<div class="video-overlay"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	

		<div id="colorlib-testimony" class="colorlib-light-grey">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Our Satisfied Guests says</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-8 col-md-offset-2 animate-box">						
						<div class="owl-carousel2">
							<div class="item">
								<div class="testimony text-center">
									<span class="user">Alysha Myers</span>
									<small>Miami Florida, USA</small>
									<blockquote>
										<p>" A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony text-center">
									<span class="user">James Fisher</span>
									<small>New York, USA</small>
									<blockquote>
										<p>One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony text-center">
									<span class="user">Jacob Webb</span>
									<small>Athens, Greece</small>
									<blockquote>
										<p>Alphabet Village and the subline of her own road, the Line Lane. Pityful a rethoric question ran over her cheek, then she continued her way.</p>
									</blockquote>
								</div>
							</div>
						</div>
					</div>
				</div>	
			</div>
		</div>

		
	
		<div id="colorlib-subscribe" style="background-image: url(images/banner/para-2.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Experience the Excitement!</h2>
					</div>
				</div>
			</div>
		</div>
	
<?php require 'footer.php';?>