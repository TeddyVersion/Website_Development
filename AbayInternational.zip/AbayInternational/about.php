<?php 
session_start();
	require 'topheader.php';
?>
		<aside id="colorlib-hero">
			<div class="flexslider">
				<ul class="slides">
			   	<li style="background-image: url(images/about/about-1.jpg);">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text">
				   				<div class="slider-text-inner text-center">
				   					<h1>About us</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			  	</ul>
		  	</div>
		</aside>

		<div id="colorlib-about">
			<div class="container">
				<div class="row">
					<div class="about-flex">
						<div class="col-one-forth aside-stretch animate-box">
							
						</div>
						<div class="col-three-forth animate-box">
							<h2>Abay International Tour and Travel</h2>
							<div class="row">
								<div class="col-md-12">
									<p>Abay International Tour and Travel is a full-service travel agency dedicated in providing totally reliable and practical tour and travel solutions as it offers most competitive rates in the market. </p>

									<p>We expertly handle local and international travel services; including airline reservations, special and customized tours from simple to unique destinations for business or pleasure trips, hotel accommodations as well as car rentals.</p>


									<div class="row row-pb-sm">
										<div class="col-md-6">
											<img class="img-responsive" src="images/about/about-2.jpg" alt="">
										</div>
										<div class="col-md-6">
											<p>Our Company was legally constituted on May 25, 2018 with Registration No. 030/2/10768 & Tour Trade license No AM/BD/1/0001879/2013 at Amhara National Regional State Trade and Market Development Bureau, Ethiopia.</p>
											<p>The General Manager of the company has an enormous experience of managing one of the biggest public transport company called ABAY BUS. </p>
										</div>
									</div>


									
								</div>
							</div>

							<div class="row" style="margin-top:50px">
								<div class="col-md-5">
									<h2>Our Mission</h2>
									<p>Adding more valuable services to customer in flight and hotel bookings, corporate travel, leisure travel and franchise. </p>
								</div>
								<div class="col-md-1"></div>
								<div class="col-md-5">
									<h2>Our Vision</h2>
									<p>Integrating travel agencies to NEXT LEVEL to achieve the market share and target audience.</p>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>

		<div id="colorlib-testimony" class="colorlib-light-grey">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Our Satisfied Guests says</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-8 col-md-offset-2 animate-box">						
						<div class="owl-carousel2">
							<div class="item">
								<div class="testimony text-center">
									<span class="user">Alysha Myers</span>
									<small>Miami Florida, USA</small>
									<blockquote>
										<p>" A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony text-center">		
									<span class="user">James Fisher</span>
									<small>New York, USA</small>
									<blockquote>
										<p>One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony text-center">
									<span class="user">Jacob Webb</span>
									<small>Athens, Greece</small>
									<blockquote>
										<p>Alphabet Village and the subline of her own road, the Line Lane. Pityful a rethoric question ran over her cheek, then she continued her way.</p>
									</blockquote>
								</div>
							</div>
						</div>
					</div>
				</div>	
			</div>
		</div>

		<div id="colorlib-subscribe" style="background-image: url(images/banner/para-2.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Experience the Excitement!</h2>
					</div>
				</div>
			</div>
		</div>

<?php require 'footer.php';?>