<?php 
session_start();
	require 'topheader.php';
?>
		<aside id="colorlib-hero">
			<div class="flexslider">
				<ul class="slides">
			   	<li style="background-image: url(images/banner/bahir-dar.jpg);">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text">
				   				<div class="slider-text-inner text-center">
				   					<h1>Bahir Dar</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			  	</ul>
		  	</div>
		</aside>

		<div id="colorlib-blog">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="wrap-division">
							<article class="animate-box">
								<div class="blog-img" style="background-image: url(images/destination/bahir-dar-2.jpg);"></div>
								
                            </article>
                            <div class="desc">
                                <h2><a href="#">Bahir Dar</a></h2>
                                <p>Bahir Dar is the capital city of the Amhara region in northern Ethiopia. It is located at 500 meters above and 600 kilometers north of Addis Ababa. Situated on the south shore of the beautiful Lake Tana, and surrounded by cool mountain air gives gentle introduction to the north of Ethiopia.</p>
                            </div>
							
                        </div>
                        
                
                    </div>
                    <div class="col-md-3">
						<div class="sidebar-wrap">
							<div class="side animate-box">
								<h3 class="sidebar-heading">Other Destinations</h3>
								<div class="blog-entry-side">
									<a href="lake-tana.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/lake-tana.jpg);"></span>
										<div class="desc">
											<h3>Lake Tana</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="blue-nile.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/blue-nile.jpg);"></span>
										<div class="desc">
											<h3>Blue Nile Falls</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
								<div class="blog-entry-side">
									<a href="gondar.php" class="blog-post">
										<span class="img" style="background-image: url(images/banner/gondar.jpg);"></span>
										<div class="desc">
											<h3>Gondar</h3>
											<span class="cat">Destination</span>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
                    
					
				</div>
			</div>
		</div>
	
		<div id="colorlib-subscribe" style="background-image: url(images/destination/bahir-dar-3.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
						<h2>Buy Yourself The Freedom</h2>
						<p>Bahir Dar is a place where you can have the relaxation you dreamed.</p>
					</div>
				</div>
			</div>
		</div>

		<div class="colorlib-tour" style="">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="f-tour" >
							<div class="row row-pb-md" >
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/bahir-dar-4.jpg);">
												
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/bahir-dar-5.jpg);">
											
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/bahir-dar-6.jpg);">
		
											</a>
										</div>
										<div class="col-md-6 animate-box">
											<a class="f-tour-img" style="background-image: url(images/destination/bahir-dar-7.jpg);">
												
											</a>
										</div>
									</div>
								</div>
								<div class="col-md-6 animate-box">
									<div class="desc">
										<div class="row">
											<div class="col-md-12">
												<h3>Bahir Dar, Ethiopia</h3>
												<p>The town has palm fringed roads and a very pleasant atmosphere. It's a nice place to explore the local market or the shoreline of Lake Tana.</p><br>
											</div>
											<div class="col-md-12">
												<h4>Places to Visit in Bahir Dar</h4>
												<div class="row">
													<div class="col-md-6">
														<ul>
															<li><a>Lake Tana</a></li>
															<li><a>Azwa Mariam Monastery</a></li>
															<li><a>Monastery of Debre Mariam</a></li>
															<li><a>Bahir Dar Market</a></li>
														</ul>
													</div>
													<div class="col-md-6">
														<ul>
															
															<li><a>Church of Debre Sina Maryam</a></li>
															<li><a>St George Church</a></li>
															<li><a>Che Che Ido</a></li>
														</ul>
													</div>
													
												</div>
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
			</div>
		</div>

<?php require 'footer.php';?>
